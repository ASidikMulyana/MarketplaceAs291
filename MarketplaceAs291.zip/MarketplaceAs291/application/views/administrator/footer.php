
<strong>Copyright &copy; 2016 - <?php echo date('Y'); ?> <a target='_BLANK' href="https://www.youtube.com/channel/UCCwTxcAOp84F55kov_TICsQ"> kk_92</a>.</strong> All rights reserved. 